
export const adjectives = [
    'Silent', 'Brave', 'Quiet', 'Wandering', 'Cosmic', 'Gentle', 'Rising', 'Falling', 
    'Hidden', 'Misty', 'Solar', 'Lunar', 'Velvet', 'Golden', 'Silver', 'Wild', 'Calm',
    'Deep', 'Healing', 'Patient', 'Steady', 'Radiant', 'Still', 'Floating', 'Drifting'
];

export const nouns = [
    'Ocean', 'Star', 'Mountain', 'River', 'Cloud', 'Rain', 'Forest', 'Moon', 'Sun',
    'Shadow', 'Echo', 'Wave', 'Breeze', 'Stone', 'Leaf', 'Sky', 'Horizon', 'Valley',
    'Dawn', 'Dusk', 'Spark', 'Ember', 'Storm', 'Tide', 'Voyager', 'Dreamer'
];

export const generateAnonymousIdentity = (): string => {
    const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
    const noun = nouns[Math.floor(Math.random() * nouns.length)];
    return `${adj} ${noun}`;
};
