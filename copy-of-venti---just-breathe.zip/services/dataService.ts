
import { supabase, supabaseUrl, supabaseAnonKey } from './supabaseClient';
import { UserData, UserProfile, JournalEntry, MoodEntry, MyStory, ChatMessage } from '../types';

// Helper for making secure, manual fetch requests to Supabase functions
const invokeFunction = async (functionName: string, body?: object) => {
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();

    if (sessionError) throw new Error('Could not get user session.');
    if (!session) throw new Error('User not authenticated.');

    const response = await fetch(`${supabaseUrl}/functions/v1/${functionName}`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
            'apikey': supabaseAnonKey,
        },
        body: JSON.stringify(body || {}), // Ensure a body is always sent
    });

    if (!response.ok) {
        const errorBody = await response.json().catch(() => ({ error: 'Failed to parse error response' }));
        throw new Error(errorBody.error || `Function invocation failed with status ${response.status}`);
    }

    // Handle cases where the function might not return a body
    const contentType = response.headers.get("content-type");
    if (contentType && contentType.indexOf("application/json") !== -1) {
        return response.json();
    }
    return {};
};

// --- DATA TRANSFORMATION HELPERS ---
// These bridge the gap between App (camelCase) and Database (snake_case)

export const toDBProfile = (profile: Partial<UserProfile>) => {
    // Explicitly map fields to prevent 'Column not found' errors
    const dbProfile: any = {};
    if (profile.name !== undefined) dbProfile.name = profile.name;
    if (profile.role !== undefined) dbProfile.role = profile.role;
    if (profile.onboardingComplete !== undefined) dbProfile.onboarding_complete = profile.onboardingComplete;
    if (profile.anonymous_display_name !== undefined) dbProfile.anonymous_display_name = profile.anonymous_display_name;
    
    // JSON columns usually stay as is, but ensuring key names match DB expectation
    if (profile.breakupContext !== undefined) dbProfile.breakup_context = profile.breakupContext;
    if (profile.exName !== undefined) dbProfile.ex_name = profile.exName;
    if (profile.shieldList !== undefined) dbProfile.shield_list = profile.shieldList;
    if (profile.baseline !== undefined) dbProfile.baseline = profile.baseline;
    
    if (profile.program !== undefined) dbProfile.program = profile.program;
    if (profile.programDay !== undefined) dbProfile.program_day = profile.programDay;
    if (profile.lastTaskCompletedDate !== undefined) dbProfile.last_task_completed_date = profile.lastTaskCompletedDate;
    
    // Streaks is a JSON column in some schemas, or separate columns. Assuming JSON 'streaks' based on types.ts, 
    // but if it errors, we might need to map to streaks_nocontact etc. keeping as json for now.
    if (profile.streaks !== undefined) dbProfile.streaks = profile.streaks;
    
    if (profile.emergencyContact !== undefined) dbProfile.emergency_contact = profile.emergencyContact;
    
    return dbProfile;
};

export const fromDBProfile = (dbRecord: any): Partial<UserProfile> => {
    if (!dbRecord) return {};
    return {
        id: dbRecord.id,
        name: dbRecord.name,
        role: dbRecord.role,
        onboardingComplete: dbRecord.onboarding_complete,
        anonymous_display_name: dbRecord.anonymous_display_name,
        breakupContext: dbRecord.breakup_context,
        exName: dbRecord.ex_name,
        shieldList: dbRecord.shield_list,
        baseline: dbRecord.baseline,
        program: dbRecord.program,
        programDay: dbRecord.program_day,
        lastTaskCompletedDate: dbRecord.last_task_completed_date,
        streaks: dbRecord.streaks,
        emergencyContact: dbRecord.emergency_contact
    };
};


// Update a user's profile data
export const updateProfile = async (userId: string, updates: Partial<UserProfile>) => {
    const dbUpdates = toDBProfile(updates);
    
    const { data, error } = await supabase
        .from('profiles')
        .update(dbUpdates)
        .eq('id', userId)
        .select()
        .single();
    
    if (error) console.error('Error updating profile:', error.message);
    return { data: data ? fromDBProfile(data) : null, error };
};

// --- Journal ---
export const addJournalEntry = async (entry: Omit<JournalEntry, 'id' | 'created_at'>) => {
    const { data, error } = await supabase
        .from('journal_entries')
        .insert(entry)
        .select()
        .single();
    if (error) console.error('Error adding journal entry:', error.message);
    return { data, error };
}

export const deleteJournalEntry = async (id: number) => {
    const { error } = await supabase.from('journal_entries').delete().eq('id', id);
    if (error) console.error('Error deleting journal entry:', error.message);
    return { error };
}

// --- Moods ---
export const addOrUpdateMood = async (moodEntry: Omit<MoodEntry, 'id' | 'created_at'>) => {
    const { data, error } = await supabase
        .from('moods')
        .upsert(moodEntry, { onConflict: 'user_id, date' })
        .select()
        .single();
    if (error) console.error('Error adding/updating mood:', error.message);
    return { data, error };
}

// --- Stories ---
export const addStory = async (story: Omit<MyStory, 'id' | 'created_at' | 'updated_at'>) => {
    const { data, error } = await supabase
        .from('my_stories')
        .insert(story)
        .select()
        .single();
    if (error) console.error('Error adding story:', error.message);
    return { data, error };
}

export const updateStory = async (id: number, updates: Partial<MyStory>) => {
    const { data, error } = await supabase
        .from('my_stories')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
    if (error) console.error('Error updating story:', error.message);
    return { data, error };
}

export const deleteStory = async (id: number) => {
    const { error } = await supabase.from('my_stories').delete().eq('id', id);
    if (error) console.error('Error deleting story:', error.message);
    return { error };
}

// --- Chat History ---
export const addChatMessage = async (message: Omit<ChatMessage, 'id' | 'created_at'>) => {
    const { data, error } = await supabase
        .from('chat_history')
        .insert(message)
        .select()
        .single();
    if (error) console.error('Error adding chat message:', error.message);
    return { data, error };
}

// --- Admin Functions ---
export type AdminUserView = Omit<UserProfile, 'journalEntries' | 'moods' | 'myStories' | 'chatHistory'> & { email: string };

export const adminGetAllUsers = async (): Promise<AdminUserView[]> => {
    try {
        const data = await invokeFunction('admin-get-users');
        return data.users;
    } catch (error) {
        console.error("Error invoking admin-get-users function:", error);
        return [];
    }
}

export const adminUpdateUserRole = async (targetUserId: string, newRole: 'user' | 'admin'): Promise<{ success: boolean; error?: string }> => {
    try {
        const body = { targetUserId, newRole };
        const data = await invokeFunction('admin-update-role', body);
        if (data.error) throw new Error(data.error);
        return { success: true };
    } catch (error: any) {
        console.error("Error invoking admin-update-role function:", error.message);
        return { success: false, error: error.message };
    }
}
