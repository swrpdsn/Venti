
import React, { useState, useEffect } from 'react';
import { supabase } from '../services/supabaseClient';
import { ShieldIcon } from '../components/Icons';

type AuthMethod = 'email' | 'phone';
type PhoneStep = 'input_phone' | 'input_otp';

const AuthScreen: React.FC = () => {
    const [authMethod, setAuthMethod] = useState<AuthMethod>('email');
    
    // Email State
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isSignUp, setIsSignUp] = useState(false);
    
    // Phone State
    const [phoneStep, setPhoneStep] = useState<PhoneStep>('input_phone');
    const [phone, setPhone] = useState('');
    const [otp, setOtp] = useState('');

    // Common State
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [message, setMessage] = useState<React.ReactNode | null>(null);
    const [showTroubleshooting, setShowTroubleshooting] = useState(false);

    // Reset state when switching methods
    useEffect(() => {
        setError(null);
        setMessage(null);
        setLoading(false);
    }, [authMethod, isSignUp]);

    // --- Phone Auth Logic ---
    const handleSendOtp = async () => {
        setLoading(true);
        setError(null);
        setMessage(null);

        if (phone.length < 10) {
            setError("Please enter a valid phone number (e.g., +15550001234).");
            setLoading(false);
            return;
        }

        try {
            const { error } = await supabase.auth.signInWithOtp({
                phone: phone
            });
            if (error) throw error;
            
            setPhoneStep('input_otp');
            setMessage("Login code sent! Please check your messages.");
        } catch (error: any) {
            console.error("Phone Auth Error:", error);
            setError(error.message || "Failed to send code. Check format.");
        } finally {
            setLoading(false);
        }
    };

    const handleVerifyOtp = async () => {
        setLoading(true);
        setError(null);

        if (otp.length !== 6) {
            setError("Please enter the 6-digit code.");
            setLoading(false);
            return;
        }

        try {
            const { error } = await supabase.auth.verifyOtp({
                phone: phone,
                token: otp,
                type: 'sms'
            });
            if (error) throw error;
            // Success handled by App.tsx subscription
        } catch (error: any) {
            console.error("Verify OTP Error:", error);
            setError(error.message || "Invalid code. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    // --- Email Auth Logic ---
    const handleEmailAuth = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        setMessage(null);

        if (!email.includes('@') || password.length < 6) {
            setError("Please enter a valid email and a password (min 6 chars).");
            setLoading(false);
            return;
        }

        try {
            if (isSignUp) {
                // Sign Up without metadata for stricter anonymity. 
                // Profile creation is handled in App.tsx with random identity generation.
                const { data, error } = await supabase.auth.signUp({ 
                    email, 
                    password,
                    options: { 
                        emailRedirectTo: window.location.origin 
                    } 
                });
                
                if (error) throw error;

                if (data.session) {
                    // User is logged in immediately
                } else {
                    // Email Confirmation is ENABLED
                    setMessage(
                        <div className="text-left">
                            <strong>Account created!</strong><br/>
                            Please check your email to confirm.
                            <br/><br/>
                            <span className="text-red-600 font-bold">Important:</span> If clicking the link gives a "localhost" error:
                            <ol className="list-decimal ml-4 mt-1">
                                <li>Go to Supabase Dashboard &gt; Auth &gt; Providers &gt; Email</li>
                                <li>Disable "Confirm Email"</li>
                                <li>Come back here and Log In</li>
                            </ol>
                        </div>
                    );
                }
            } else {
                const { error } = await supabase.auth.signInWithPassword({ email, password });
                if (error) throw error;
            }
        } catch (error: any) {
            setError(error.message || "Authentication failed.");
        } finally {
            setLoading(false);
        }
    };

    const handleForgotPassword = async () => {
         if (!email.includes('@')) {
            setError("Please enter your email address first.");
            return;
        }
        setLoading(true);
        try {
            const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: window.location.origin });
            if (error) throw error;
            setMessage("Password reset link sent! If the link fails, check the troubleshooting section below.");
        } catch (error: any) {
            setError(error.message);
        } finally {
            setLoading(false);
        }
    }

    // --- Styles ---
    const isDawn = document.documentElement.classList.contains('theme-dawn');
    const containerClass = isDawn ? 'bg-white/80' : 'bg-slate-900/80';
    const textClass = isDawn ? 'text-slate-800' : 'text-slate-100';
    const inputClass = `w-full p-3 rounded-lg border focus:ring-2 focus:outline-none transition-all ${
        isDawn 
        ? 'bg-white border-slate-300 focus:border-dawn-primary focus:ring-dawn-primary/20 text-slate-800' 
        : 'bg-slate-800 border-slate-600 focus:border-dusk-primary focus:ring-dusk-primary/20 text-white placeholder-slate-400'
    }`;
    const buttonPrimaryClass = `w-full py-3 rounded-lg font-bold transition-all transform active:scale-95 ${
        isDawn 
        ? 'bg-dawn-primary text-white hover:bg-dawn-primary/90 shadow-lg shadow-dawn-primary/20' 
        : 'bg-dusk-primary text-dusk-bg-start hover:bg-dusk-primary/90 shadow-lg shadow-dusk-primary/20'
    }`;
    const buttonSecondaryClass = `w-full py-3 rounded-lg font-bold transition-all border ${
        isDawn
        ? 'border-slate-300 text-slate-600 hover:bg-slate-50'
        : 'border-slate-600 text-slate-300 hover:bg-slate-800'
    }`;
    const activeTabClass = isDawn 
        ? 'border-b-2 border-dawn-primary text-dawn-primary' 
        : 'border-b-2 border-dusk-primary text-dusk-primary';
    const inactiveTabClass = isDawn 
        ? 'text-slate-500 hover:text-slate-700' 
        : 'text-slate-400 hover:text-slate-200';

    return (
        <div className="flex flex-col items-center justify-center min-h-screen p-4 animate-fade-in pb-20">
             <div className="mb-8 text-center">
                <h1 className={`text-5xl font-thin tracking-widest uppercase mb-2 ${isDawn ? 'text-dawn-primary' : 'text-dusk-primary'}`}>Venti</h1>
                <p className={`text-lg italic tracking-wide ${isDawn ? 'text-slate-600' : 'text-slate-300'}`}>...Just Breathe</p>
            </div>

            <div className={`w-full max-w-md p-8 rounded-2xl shadow-2xl backdrop-blur-md ${containerClass}`}>
                
                {/* Auth Method Tabs */}
                <div className="flex mb-6 border-b border-slate-200 dark:border-slate-700">
                    <button 
                        className={`flex-1 pb-3 font-semibold text-lg transition-colors ${authMethod === 'email' ? activeTabClass : inactiveTabClass}`}
                        onClick={() => setAuthMethod('email')}
                    >
                        Email
                    </button>
                    <button 
                        className={`flex-1 pb-3 font-semibold text-lg transition-colors ${authMethod === 'phone' ? activeTabClass : inactiveTabClass}`}
                        onClick={() => setAuthMethod('phone')}
                    >
                        Phone
                    </button>
                </div>

                {message && (
                    <div className="mb-4 p-3 rounded-lg bg-green-100 border border-green-200 text-green-800 text-sm">
                        {message}
                    </div>
                )}

                {error && (
                    <div className="mb-4 p-3 rounded-lg bg-red-100 border border-red-200 text-red-700 text-sm text-center">
                        {error}
                    </div>
                )}

                {authMethod === 'email' ? (
                    <form onSubmit={handleEmailAuth} className="space-y-4">
                        <div>
                            <label className={`block text-sm font-medium mb-1 ${textClass}`}>Email Address</label>
                            <input 
                                type="email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className={inputClass}
                                placeholder="you@example.com"
                                required
                            />
                        </div>
                        <div>
                            <label className={`block text-sm font-medium mb-1 ${textClass}`}>Password</label>
                            <input 
                                type="password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className={inputClass}
                                placeholder="••••••••"
                                required
                            />
                            {!isSignUp && (
                                <button 
                                    type="button"
                                    onClick={handleForgotPassword}
                                    className={`text-xs mt-1 hover:underline float-right ${isDawn ? 'text-dawn-secondary' : 'text-dusk-secondary'}`}
                                >
                                    Forgot Password?
                                </button>
                            )}
                        </div>
                        
                        <div className="pt-2">
                            <button type="submit" disabled={loading} className={buttonPrimaryClass}>
                                {loading ? 'Processing...' : (isSignUp ? 'Sign Up' : 'Log In')}
                            </button>
                        </div>

                        <div className="text-center mt-4">
                            <p className={`text-sm ${textClass}`}>
                                {isSignUp ? "Already have an account?" : "Don't have an account?"}{" "}
                                <button 
                                    type="button"
                                    onClick={() => setIsSignUp(!isSignUp)}
                                    className={`font-bold hover:underline ${isDawn ? 'text-dawn-secondary' : 'text-dusk-secondary'}`}
                                >
                                    {isSignUp ? "Log In" : "Sign Up"}
                                </button>
                            </p>
                        </div>
                    </form>
                ) : (
                    <div className="space-y-4">
                        {phoneStep === 'input_phone' ? (
                            <>
                                <div>
                                    <label className={`block text-sm font-medium mb-1 ${textClass}`}>Phone Number</label>
                                    <input 
                                        type="tel" 
                                        value={phone}
                                        onChange={(e) => setPhone(e.target.value)}
                                        className={inputClass}
                                        placeholder="+1 555 000 0000"
                                    />
                                    <p className={`text-xs mt-1 ${isDawn ? 'text-slate-500' : 'text-slate-400'}`}>Include country code (e.g. +1 for US, +91 for India)</p>
                                </div>
                                <div className="pt-2">
                                    <button onClick={handleSendOtp} disabled={loading} className={buttonPrimaryClass}>
                                        {loading ? 'Sending...' : 'Get Login Code'}
                                    </button>
                                </div>
                            </>
                        ) : (
                            <>
                                <div>
                                    <label className={`block text-sm font-medium mb-1 ${textClass}`}>Enter Verification Code</label>
                                    <input 
                                        type="text" 
                                        value={otp}
                                        onChange={(e) => setOtp(e.target.value)}
                                        className={`${inputClass} text-center text-2xl tracking-widest`}
                                        placeholder="000000"
                                        maxLength={6}
                                    />
                                </div>
                                <div className="pt-2 space-y-3">
                                    <button onClick={handleVerifyOtp} disabled={loading} className={buttonPrimaryClass}>
                                        {loading ? 'Verifying...' : 'Verify & Login'}
                                    </button>
                                    <button 
                                        onClick={() => { setPhoneStep('input_phone'); setOtp(''); }}
                                        className={buttonSecondaryClass}
                                    >
                                        Change Phone Number
                                    </button>
                                </div>
                            </>
                        )}
                    </div>
                )}
            </div>

            {/* Troubleshooting Section */}
            <div className="w-full max-w-md mt-6">
                <button 
                    onClick={() => setShowTroubleshooting(!showTroubleshooting)}
                    className={`flex items-center justify-center w-full text-sm font-semibold ${isDawn ? 'text-slate-600' : 'text-slate-400'} hover:underline`}
                >
                    <ShieldIcon className="w-4 h-4 mr-1" />
                    Having Login Issues? (Localhost Error)
                </button>
                
                {showTroubleshooting && (
                    <div className={`mt-2 p-4 rounded-lg text-sm ${isDawn ? 'bg-white/50 text-slate-700' : 'bg-black/30 text-slate-300'}`}>
                        <p className="font-bold mb-2">"Localhost refused to connect"?</p>
                        <p className="mb-2">This happens when Supabase tries to confirm your email but redirects to a default local URL that doesn't exist.</p>
                        <p className="font-bold mb-1">To Fix:</p>
                        <ul className="list-disc ml-4 space-y-1">
                            <li>Go to Supabase Dashboard.</li>
                            <li>Authentication &gt; Providers &gt; Email.</li>
                            <li><strong>Disable "Confirm Email".</strong></li>
                            <li>Then return here and Sign Up / Log In again.</li>
                        </ul>
                    </div>
                )}
            </div>
        </div>
    );
};

export default AuthScreen;
